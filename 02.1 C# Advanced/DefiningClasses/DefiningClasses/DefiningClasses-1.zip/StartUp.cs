﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            // Task 1
            Person person1 = new Person();
            person1.Name = "Peter";
            person1.Age = 20;

            Person person2 = new Person
            {
                Name = "George",
                Age = 18
            };

            Person person3 = new Person
            {
                Name = "Sam",
                Age = 43
            };

            Console.WriteLine("Name: \t Age:");
            Console.WriteLine($"{person1.Name} \t {person1.Age}");
            Console.WriteLine($"{person2.Name} \t {person2.Age}");
            Console.WriteLine($"{person3.Name} \t {person3.Age}");
        }
    }
}
