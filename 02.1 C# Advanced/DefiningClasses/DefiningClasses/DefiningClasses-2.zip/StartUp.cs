﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            // Task 1
            Person person1 = new Person();
            person1.Name = "Peter";
            person1.Age = 20;

            Person person2 = new Person
            {
                Name = "George",
                Age = 18
            };

            Person person3 = new Person
            {
                Name = "Sam",
                Age = 43
            };

            Person person4 = new Person();
            Person person5 = new Person(22);
            Person person6 = new Person("Leo", 31);


            Console.WriteLine("Name: \t Age:");
            Console.WriteLine($"{person1.Name} \t {person1.Age}");
            Console.WriteLine($"{person2.Name} \t {person2.Age}");
            Console.WriteLine($"{person3.Name} \t {person3.Age}");
            Console.WriteLine($"{person4.Name} \t {person4.Age}");
            Console.WriteLine($"{person5.Name} \t {person5.Age}");
            Console.WriteLine($"{person6.Name} \t {person6.Age}");
        }
    }
}
