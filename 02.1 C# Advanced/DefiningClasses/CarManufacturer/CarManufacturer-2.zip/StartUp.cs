﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            // Task 1
            Car car = new Car();

            car.Make = "VW";
            car.Model = "MK3";
            car.Year = 1992;
            // Task 2
            car.FuelQuantity = 200;
            car.FuelConsumption = 200;
            car.Drive(2000);

            // Task 1
            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");

            // Task 2
            Console.WriteLine(car.WhoAmI());
        }
    }
}
