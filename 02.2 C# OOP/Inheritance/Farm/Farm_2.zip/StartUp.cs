﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // Task 1
            //Dog dog = new Dog();
            //dog.Bark();
            //dog.Eat();

            // Task 2
            Puppy puppy = new Puppy();
            puppy.Eat();
            puppy.Bark();
            puppy.Weep();
        }
    }
}
