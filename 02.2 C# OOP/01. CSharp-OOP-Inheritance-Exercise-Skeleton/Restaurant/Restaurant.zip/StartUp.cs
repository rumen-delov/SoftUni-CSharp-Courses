﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Coffee coffee = new Coffee("Lavazza", 0.2);

            //coffee.Price = 1.80m;

            //Console.WriteLine($"Drink name: {coffee.Name}");
            //Console.WriteLine($"Drink price: {coffee.Price}");
            //Console.WriteLine($"Drink milliliters: {coffee.Milliliters}");
            //Console.WriteLine($"Drink caffeine: {coffee.Caffeine}");
        }
    }
}