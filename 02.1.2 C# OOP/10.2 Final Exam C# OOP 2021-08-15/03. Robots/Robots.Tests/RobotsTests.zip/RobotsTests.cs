﻿namespace Robots.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class RobotsTests
    {
        private Robot robot;

        [SetUp]
        public void Setup()
        {
            robot = new Robot("Wall-E", 100);
        }

        [Test]
        public void CheckIfRobotsNameIsRight()
        {
            Assert.That(robot.Name, Is.EqualTo("Wall-E"));
        }

        [Test]
        public void SetRobotsName()
        {
            robot.Name = "R2D2";
            Assert.That(robot.Name, Is.EqualTo("R2D2"));
        }

        [Test]
        public void CheckRobotsInitialBatteryStatus()
        {
            Assert.That(robot.Battery, Is.EqualTo(100));
        }

        [Test]
        public void CheckIfRobotsMaxBatteryWithAllowedValue()
        {
            Assert.That(robot.MaximumBattery, Is.EqualTo(100));
        }
    }
}
